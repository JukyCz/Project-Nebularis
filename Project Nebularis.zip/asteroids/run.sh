#!/bin/bash
echo "Installing dependencies..."
npm install
echo "Starting the game..."
npm run dev